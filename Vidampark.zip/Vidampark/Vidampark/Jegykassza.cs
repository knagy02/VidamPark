﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vidampark
{
    public class Jegykassza
    {
        public int JegyArSzamitas(int eletkor, bool hetvege){

            if (eletkor < 0)
                throw new ArgumentException("Az életkor negatív");

            int osszeg = 0;

            if (eletkor > 6 && eletkor <= 18)
                osszeg = 3000;
            else if (eletkor > 18)
                osszeg = 5000;
           
            if(hetvege && eletkor > 6)
               osszeg += 1000;
            

            return osszeg;
                
                 



        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vidampark
{
    public class BiztonsagiEllenor
    {
        public bool FelulhetE(int magassagCm, string jatekNev)
        {
            if (magassagCm == 0 || magassagCm < 0)
            {
                throw new ArgumentException("A magasság negatív");





            }
            if (jatekNev == "Hullamvasut"&&magassagCm>=140)
            {
                return true;
            }
            else if (jatekNev == "Hullamvasut" && magassagCm <140)
            {
                return false;
            }
            else if (jatekNev == "Dodgem" && magassagCm >= 120)
            {
                return true;
            }
            else if (jatekNev == "Dodgem" && magassagCm < 120)
            {
                return false;
            }
            else
                return false;






        }
    }
}

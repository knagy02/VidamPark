﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vidampark.Tests.Unit
{
    public class JegykasszaTests
    {
        [Fact]
        public void JegyArSzamitas_behateves_kiNulla()
        {
            
            Jegykassza f=new Jegykassza();
            int kor = 3;
            bool hetvege=false;

            int act=f.JegyArSzamitas(kor, hetvege);

            Assert.Equal(0, act);   






        }
        [Fact]
        public void FelulhetE_min140()
        {

            BiztonsagiEllenor k=new BiztonsagiEllenor();
            int magassagCm = 150;
            string jatekNev = "Dodgem";
            bool act = k.FelulhetE(magassagCm, jatekNev);

            Assert.Equal(true, act);






        }







    }
}
